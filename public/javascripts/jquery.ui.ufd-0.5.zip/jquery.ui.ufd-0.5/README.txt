	ufd 0.5	: Unobtrusive fast filter drop down jQuery plugin.
	
	Authors: 
		thetoolman@gmail.com 
		Kadalashvili.Vladimir@gmail.com
		
	Version: 0.5
	
	Website: http://code.google.com/p/ufd/
	
	See examples/index.html for demonstration page, or visit the website for documentation.	
